# ComfyUI-FastModelHopper

Sidebar panel that copies models from a slow HDD onto the fast SSD where ComfyUI reads them. Unload deletes only the SSD copy. HDD files are never moved or deleted.

## Install
1. Put the `ComfyUI-FastModelHopper` folder in `ComfyUI/custom_nodes/`.
2. Restart ComfyUI.
3. Open the **FMH** tab on the left sidebar.

## Use
1. **Source** — full path of the HDD folder that holds the models (hierarchy is shown as-is).
2. **Destination** — full path of the ComfyUI `models` folder on the SSD.
3. **Target folder** — which models subfolder to copy into (`checkpoints`, `loras`, `diffusion_models`, …).
4. Check models. They turn **yellow**.
5. **Load** copies those files (folder structure kept) into `Destination\Target folder`.
6. Copied files show in the bottom list with **green** checkboxes. The title turns green.
7. Check green items and click **Unload** to delete them from the SSD. Source checkboxes go back to red.
8. **Refresh** rescans both disks and sets red / yellow / green from what is actually there.
9. The bottom line shows free space on the SSD.

The checkbox beside a model's folder dropdown keeps the HDD folders on the SSD. It is off by default, so only the file is copied. The same checkbox on a folder applies to every model inside it.

A model that is not on the SSD has a purple name. Copy progress is the bar under the buttons. Errors open in the red warning panel.


A model that is on the SSD but not on the HDD is purple. Check it, use **Select folder** or **Select file**, then **Move to HDD**. That moves the file off the SSD. Green files are copies that still exist on the HDD.
